package com.example.sqliteexample;

public class TransactionModelClass {

    Integer id;
    String name;
    String amount;
    String category;
    
    public TransactionModelClass()
    {}


    public TransactionModelClass(String name, String amount) {
        this.name = name;
        this.amount = amount;
    }

    public TransactionModelClass(Integer id, String name, String amount, String category) {
        this.id = id;
        this.name = name;
        this.amount = amount;
        this.category = category;
    }

    public TransactionModelClass(Integer id, String name, String amount) {
        this.id = id;
        this.name = name;
        this.amount = amount;
    }

    public TransactionModelClass(String stringName, String stringAmount, String stringCategory) {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }
}
