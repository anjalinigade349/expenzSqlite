package com.example.sqliteexample;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class TransactionAdapterClass extends RecyclerView.Adapter<TransactionAdapterClass.ViewHolder> {

    List<TransactionModelClass> transaction;
    Context context;
    DatabaseHelperClass databaseHelperClass;

    public TransactionAdapterClass(List<TransactionModelClass> transaction, Context context) {
        this.transaction = transaction;
        this.context = context;
        databaseHelperClass = new DatabaseHelperClass(context);
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View view = layoutInflater.inflate(R.layout.transaction_item_list,parent,false);
        ViewHolder viewHolder = new ViewHolder(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull final ViewHolder holder, final int position) {
        final TransactionModelClass transactionModelClass = transaction.get(position);

        holder.textViewID.setText(Integer.toString(transactionModelClass.getId()));
        holder.editText_Name.setText(transactionModelClass.getName());
        holder.editText_Amount.setText(transactionModelClass.getAmount());
        holder.editText_Category.setText(transactionModelClass.getCategory());

       // holder.editText_Date.setText(transactionModelClass.getDate());

        holder.button_Edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String stringName = holder.editText_Name.getText().toString();
                String stringAmount = holder.editText_Amount.getText().toString();
                String stringCategory=holder.editText_Category.getText().toString();

                databaseHelperClass.updateTransaction(new TransactionModelClass(transactionModelClass.getId(),stringName,stringAmount,stringCategory));
                notifyDataSetChanged();
                ((Activity) context).finish();
                context.startActivity(((Activity) context).getIntent());
            }
        });

        holder.button_delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                databaseHelperClass.deleteTransaction(transactionModelClass.getId());
                transaction.remove(position);
                notifyDataSetChanged();
            }
        });

    }

    @Override
    public int getItemCount() {
        return transaction.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        TextView textViewID;
        EditText editText_Name;
        EditText editText_Amount;
        EditText editText_Category;
        EditText editText_Date;
        Button button_Edit;
        Button button_delete;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            textViewID = itemView.findViewById(R.id.text_id);
            editText_Name = itemView.findViewById(R.id.edittext_name);
            editText_Amount = itemView.findViewById(R.id.edittext_amount);
            editText_Category=itemView.findViewById(R.id.edittext_category);
           // editText_Date = itemView.findViewById(R.id.edittext_ca);
            button_delete = itemView.findViewById(R.id.button_delete);
            button_Edit = itemView.findViewById(R.id.button_edit);

        }
    }
}
